function addtocart(table, pid, action) {
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() {

		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			if (xmlhttp.responseText.trim() == 'successfulisbuy') {
				window.location = "cart.jsp";
			}
			if (xmlhttp.responseText.trim() == 'successful') {
				alert('product added');
			}
		}

	};

	xmlhttp.open("POST", "addtocart.jsp", true);
	xmlhttp.setRequestHeader("Content-type",
			"application/x-www-form-urlencoded");
	xmlhttp.send("table=" + table + "&pid=" + pid + "&action=" + action);
}