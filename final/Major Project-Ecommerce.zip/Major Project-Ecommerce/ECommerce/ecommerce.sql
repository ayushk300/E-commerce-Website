-- MySQL dump 10.13  Distrib 5.5.40, for Win32 (x86)
--
-- Host: localhost    Database: ecommerce
-- ------------------------------------------------------
-- Server version	5.5.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `addressid` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(60) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `pincode` int(11) DEFAULT NULL,
  `address2` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`addressid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` VALUES (1,'sector 23 swarn path','Rajasthan','jaipur',302020,'mansarovar'),(2,'11/127 kaveri path','rajasthan','jaipur',302020,'mansarovar'),(3,'some address','haryana','gurgaon',652145,'sonipat'),(4,'some address','haryana','gurgaon',652145,'sonipat'),(5,'jhjdhfjdhfjdhfjdhjfhdfjh','','Jaipur',302078,''),(6,'jhjdhfjdhfjdhfjdhjfhdfjh','jhjdhfjdhjdhf','Jaipur',302078,'jhjdhfjdhjdhf'),(7,'jhjdhfjdhfjdhfjdhjfhdfjh','','Jaipur',302078,''),(8,'Some address','Rajasthan','Jaipur',302078,'');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `books` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `language` varchar(15) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `author` varchar(30) NOT NULL,
  `publisher` varchar(30) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  `length` int(11) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (1,'harry potter','harry potter book description',2500,'english',10,'rowling','some publisher','wxp (11).jpg',500),(2,'harry potter','harry potter book description',50000,'english',10,'rowling','some publisher','wxp (4).jpg',500),(3,'ihone','this is an ihone',50000,'english',10,'rowling','some publisher','wxp (3).jpg',500),(4,'harry potter','this is an ihone',50000,'english',10,'rowling','some publisher','wxp (1).jpg',500),(5,'one night at the call center','this is a very beautiful novel written  by Chetan bhagat',425,'english',5,'chetan bhagat','hariom publications','wxp (11).jpg',670),(6,'one night at the call center 2','this is a very beautiful novel written  by Chetan bhagat',425,'english',5,'chetan bhagat','hariom publications','wxp (16).jpg',670);
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cameraandaccessories`
--

DROP TABLE IF EXISTS `cameraandaccessories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cameraandaccessories` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `type` varchar(25) NOT NULL,
  `quantity` int(11) NOT NULL,
  `warranty` int(11) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cameraandaccessories`
--

LOCK TABLES `cameraandaccessories` WRITE;
/*!40000 ALTER TABLE `cameraandaccessories` DISABLE KEYS */;
INSERT INTO `cameraandaccessories` VALUES (1,'Canon','Point and',5000,'canon','point and shoot',8,2,'wxp (2).jpg');
/*!40000 ALTER TABLE `cameraandaccessories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `footwearmen`
--

DROP TABLE IF EXISTS `footwearmen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `footwearmen` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `size` varchar(5) NOT NULL,
  `quantity` int(11) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `footwearmen`
--

LOCK TABLES `footwearmen` WRITE;
/*!40000 ALTER TABLE `footwearmen` DISABLE KEYS */;
INSERT INTO `footwearmen` VALUES (1,'name','this is desciption',500,'apple','32',10,'image.jpg'),(2,'name','this is desciption',500,'apple','32',10,'image.jpg'),(3,'ihone','this is an ihone',50000,'apple','32',10,'IMG20150515193918.jpg'),(4,'ihone','this is an ihone',50000,'apple','32',10,'wxp (1).png'),(5,'ihone','this is an ihone',50000,'','',10,'wxp (3).jpg'),(6,'ihone','this is an ihone',50000,'','',10,'wxp (3).jpg'),(7,'sandal','harry potter book description',50000,'puma','8',10,'IMG20150515193946.jpg'),(8,'Puma Sneakers','this is the description for sneakers',4200,'puma','8',10,'wxp (4).jpg');
/*!40000 ALTER TABLE `footwearmen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `footwearwomen`
--

DROP TABLE IF EXISTS `footwearwomen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `footwearwomen` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `size` varchar(5) NOT NULL,
  `quantity` int(11) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `footwearwomen`
--

LOCK TABLES `footwearwomen` WRITE;
/*!40000 ALTER TABLE `footwearwomen` DISABLE KEYS */;
INSERT INTO `footwearwomen` VALUES (1,'sandal','this is the description for sandals',2500,'lee cooper','9',5,'wxp (3).jpg'),(2,'ihone','this is an ihone',50000,'apple','32',10,'wxp (1).png');
/*!40000 ALTER TABLE `footwearwomen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formalandcasualshirtmen`
--

DROP TABLE IF EXISTS `formalandcasualshirtmen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `formalandcasualshirtmen` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `size` varchar(5) NOT NULL,
  `quantity` int(11) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formalandcasualshirtmen`
--

LOCK TABLES `formalandcasualshirtmen` WRITE;
/*!40000 ALTER TABLE `formalandcasualshirtmen` DISABLE KEYS */;
INSERT INTO `formalandcasualshirtmen` VALUES (1,'ihone','this is an ihone',50000,'apple','32',10,'wxp (1).png'),(2,'ihone','this is an ihone',50000,'puma','8',10,'wxp (3).jpg');
/*!40000 ALTER TABLE `formalandcasualshirtmen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formalclotheswomen`
--

DROP TABLE IF EXISTS `formalclotheswomen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `formalclotheswomen` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `size` varchar(5) NOT NULL,
  `quantity` int(11) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  `subcategory` varchar(20) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formalclotheswomen`
--

LOCK TABLES `formalclotheswomen` WRITE;
/*!40000 ALTER TABLE `formalclotheswomen` DISABLE KEYS */;
INSERT INTO `formalclotheswomen` VALUES (1,'Canon','harry potter book description',50000,'puma','8',10,'wxp (7).jpg','blazers');
/*!40000 ALTER TABLE `formalclotheswomen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homeandkitchenappliances`
--

DROP TABLE IF EXISTS `homeandkitchenappliances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `homeandkitchenappliances` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  `warranty` int(11) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homeandkitchenappliances`
--

LOCK TABLES `homeandkitchenappliances` WRITE;
/*!40000 ALTER TABLE `homeandkitchenappliances` DISABLE KEYS */;
INSERT INTO `homeandkitchenappliances` VALUES (1,'ihone','harry potter book description',2500,'maharaja',10,2,'wxp (1).png');
/*!40000 ALTER TABLE `homeandkitchenappliances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jeansandtrousersmen`
--

DROP TABLE IF EXISTS `jeansandtrousersmen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jeansandtrousersmen` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `size` varchar(5) NOT NULL,
  `quantity` int(11) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jeansandtrousersmen`
--

LOCK TABLES `jeansandtrousersmen` WRITE;
/*!40000 ALTER TABLE `jeansandtrousersmen` DISABLE KEYS */;
INSERT INTO `jeansandtrousersmen` VALUES (1,'ihone','this is an ihone',50000,'apple','32',10,'wxp (1).png');
/*!40000 ALTER TABLE `jeansandtrousersmen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jeansandtrouserswomen`
--

DROP TABLE IF EXISTS `jeansandtrouserswomen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jeansandtrouserswomen` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `size` varchar(5) NOT NULL,
  `quantity` int(11) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jeansandtrouserswomen`
--

LOCK TABLES `jeansandtrouserswomen` WRITE;
/*!40000 ALTER TABLE `jeansandtrouserswomen` DISABLE KEYS */;
INSERT INTO `jeansandtrouserswomen` VALUES (1,'ihone','this is an ihone',50000,'apple','32',10,'wxp (1).png');
/*!40000 ALTER TABLE `jeansandtrouserswomen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kurtasandsarees`
--

DROP TABLE IF EXISTS `kurtasandsarees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kurtasandsarees` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `size` varchar(5) NOT NULL,
  `quantity` int(11) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kurtasandsarees`
--

LOCK TABLES `kurtasandsarees` WRITE;
/*!40000 ALTER TABLE `kurtasandsarees` DISABLE KEYS */;
INSERT INTO `kurtasandsarees` VALUES (1,'ihone','this is an ihone',50000,'apple','32',10,'wxp (1).png');
/*!40000 ALTER TABLE `kurtasandsarees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `laptopandaccessories`
--

DROP TABLE IF EXISTS `laptopandaccessories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laptopandaccessories` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `size` varchar(5) NOT NULL,
  `quantity` int(11) NOT NULL,
  `warranty` int(11) NOT NULL,
  `color` varchar(10) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laptopandaccessories`
--

LOCK TABLES `laptopandaccessories` WRITE;
/*!40000 ALTER TABLE `laptopandaccessories` DISABLE KEYS */;
INSERT INTO `laptopandaccessories` VALUES (1,'ihone','harry potter book description',50000,'lenovo','15',8,5,'black','wxp (6).jpg');
/*!40000 ALTER TABLE `laptopandaccessories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobileandtablets`
--

DROP TABLE IF EXISTS `mobileandtablets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobileandtablets` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `type` varchar(15) NOT NULL,
  `quantity` int(11) NOT NULL,
  `warranty` int(11) NOT NULL,
  `color` varchar(10) NOT NULL,
  `size` int(11) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobileandtablets`
--

LOCK TABLES `mobileandtablets` WRITE;
/*!40000 ALTER TABLE `mobileandtablets` DISABLE KEYS */;
INSERT INTO `mobileandtablets` VALUES (1,'ihone','this is an ihone',50000,'apple','smart',10,5,'golden',6,'wxp (6).jpg');
/*!40000 ALTER TABLE `mobileandtablets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moviesandtvshows`
--

DROP TABLE IF EXISTS `moviesandtvshows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moviesandtvshows` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `language` varchar(15) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  `duration` int(11) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moviesandtvshows`
--

LOCK TABLES `moviesandtvshows` WRITE;
/*!40000 ALTER TABLE `moviesandtvshows` DISABLE KEYS */;
INSERT INTO `moviesandtvshows` VALUES (1,'Canon','Point and',50000,'english',8,'wxp (7).jpg',150);
/*!40000 ALTER TABLE `moviesandtvshows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nextorderid`
--

DROP TABLE IF EXISTS `nextorderid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nextorderid` (
  `orderid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nextorderid`
--

LOCK TABLES `nextorderid` WRITE;
/*!40000 ALTER TABLE `nextorderid` DISABLE KEYS */;
INSERT INTO `nextorderid` VALUES (6558);
/*!40000 ALTER TABLE `nextorderid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `orderid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `addressid` int(11) DEFAULT NULL,
  `status` varchar(15) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`orderid`),
  KEY `userid` (`userid`),
  KEY `addressid` (`addressid`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`),
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`addressid`) REFERENCES `addresses` (`addressid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (6551,1,1,'Received',1,50000),(6552,1,1,'Received',1,37500),(6553,1,1,'Received',1,37000),(6554,24,8,'Received',1,50000),(6555,24,8,'Received',1,2500),(6556,24,8,'Received',1,50000),(6557,24,8,'Received',1,37500);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stationariesandotherequipment`
--

DROP TABLE IF EXISTS `stationariesandotherequipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stationariesandotherequipment` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stationariesandotherequipment`
--

LOCK TABLES `stationariesandotherequipment` WRITE;
/*!40000 ALTER TABLE `stationariesandotherequipment` DISABLE KEYS */;
INSERT INTO `stationariesandotherequipment` VALUES (1,'ihone','this is an ihone',50000,10,'wxp (1).png');
/*!40000 ALTER TABLE `stationariesandotherequipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `televisions`
--

DROP TABLE IF EXISTS `televisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `televisions` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `type` varchar(5) NOT NULL,
  `quantity` int(11) NOT NULL,
  `warranty` int(11) NOT NULL,
  `size` varchar(5) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `televisions`
--

LOCK TABLES `televisions` WRITE;
/*!40000 ALTER TABLE `televisions` DISABLE KEYS */;
INSERT INTO `televisions` VALUES (1,'ihone','harry potter book description',50000,'sony','smart',10,5,'32','wxp (1).png');
/*!40000 ALTER TABLE `televisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tshirtandtopwomen`
--

DROP TABLE IF EXISTS `tshirtandtopwomen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tshirtandtopwomen` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `size` varchar(5) NOT NULL,
  `quantity` int(11) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tshirtandtopwomen`
--

LOCK TABLES `tshirtandtopwomen` WRITE;
/*!40000 ALTER TABLE `tshirtandtopwomen` DISABLE KEYS */;
INSERT INTO `tshirtandtopwomen` VALUES (1,'ihone','this is an ihone',50000,'apple','32',10,'wxp (1).png');
/*!40000 ALTER TABLE `tshirtandtopwomen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tshirtsmen`
--

DROP TABLE IF EXISTS `tshirtsmen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tshirtsmen` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(70) NOT NULL,
  `description` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `size` varchar(5) NOT NULL,
  `quantity` int(11) NOT NULL,
  `imagename` varchar(25) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tshirtsmen`
--

LOCK TABLES `tshirtsmen` WRITE;
/*!40000 ALTER TABLE `tshirtsmen` DISABLE KEYS */;
INSERT INTO `tshirtsmen` VALUES (1,'ihone','this is an ihone',50000,'apple','32',10,'wxp (5).jpg');
/*!40000 ALTER TABLE `tshirtsmen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `mobile` longtext,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Amit Sharma','sharma.amit285@gmail.com','fgfgf3465347hgdhg','8764038458'),(2,'Akshay Bansal','akshay.3bansal@gmail.com','f5454465347hgdhg','8764038452'),(24,'Amit','sharma.amit2530@gmail.com','d8578edf8458ce06fbc5bb76a58c5ca4','8384933461'),(25,'Amit','sharma.amit253011@gmail.','a384b6463fc216a5f8ecb6670f86456a','8384933461'),(26,'Amit','sumit2368@gmail.com','d8578edf8458ce06fbc5bb76a58c5ca4','8384933461'),(27,'','','d41d8cd98f00b204e9800998ecf8427e','');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useraddress`
--

DROP TABLE IF EXISTS `useraddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `useraddress` (
  `useraddressid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `addressid` int(11) DEFAULT NULL,
  PRIMARY KEY (`useraddressid`),
  KEY `addressid` (`addressid`),
  KEY `userid` (`userid`),
  CONSTRAINT `useraddress_ibfk_1` FOREIGN KEY (`addressid`) REFERENCES `addresses` (`addressid`),
  CONSTRAINT `useraddress_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useraddress`
--

LOCK TABLES `useraddress` WRITE;
/*!40000 ALTER TABLE `useraddress` DISABLE KEYS */;
INSERT INTO `useraddress` VALUES (1,1,1),(2,2,2),(3,24,8);
/*!40000 ALTER TABLE `useraddress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voucher`
--

DROP TABLE IF EXISTS `voucher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voucher` (
  `vid` int(11) NOT NULL,
  `voucher` varchar(15) NOT NULL,
  `applicableto` varchar(10) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  PRIMARY KEY (`vid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voucher`
--

LOCK TABLES `voucher` WRITE;
/*!40000 ALTER TABLE `voucher` DISABLE KEYS */;
INSERT INTO `voucher` VALUES (1,'NEW25','all',25),(2,'SPECIAL26','all',26);
/*!40000 ALTER TABLE `voucher` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-05-17  8:42:14
