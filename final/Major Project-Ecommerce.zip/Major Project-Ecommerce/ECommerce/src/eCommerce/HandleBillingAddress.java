package eCommerce;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class HandleBillingAddress
 */
@WebServlet("/HandleBillingAddress")
public class HandleBillingAddress extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HandleBillingAddress() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			handleAddress(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			handleAddress(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void handleAddress(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException,
			SQLException {
		HttpSession session = request.getSession();
		final String name = request.getParameter("fullname");
		final String mobileno = request.getParameter("mobno");
		final String address1 = request.getParameter("add_line1");
		final String address2 = request.getParameter("add_line2");
		final String pincode = request.getParameter("pincode");
		final String city = request.getParameter("city");
		final String state = request.getParameter("state");
		if (name != null && mobileno != null && address1 != null
				&& address2 != null && pincode != null && city != null
				&& state != null) {
			session.setAttribute("name", name);
			session.setAttribute("mobile", mobileno);
			session.setAttribute("address1", address1);
			session.setAttribute("address2", address2);
			session.setAttribute("pincode", pincode);
			session.setAttribute("city", city);
			session.setAttribute("state", state);

			if (session.getAttribute("addressid").toString()
					.equalsIgnoreCase("-1")
					&& !session.getAttribute("userid").toString()
							.equalsIgnoreCase("-1")) {
				ConnectionHandler connectionHandler = new ConnectionHandler();
				Connection connection = connectionHandler.getConnection();
				PreparedStatement pstmt = connection
						.prepareStatement("insert into addresses (address,state,city,pincode,address2) values(?,?,?,?,?)");
				pstmt.setString(1, address1);
				pstmt.setString(2, address2);
				pstmt.setString(3, city);
				pstmt.setInt(4, Integer.parseInt(pincode));
				pstmt.setString(5, address2);
				pstmt.executeUpdate();
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement
						.executeQuery("select * from addresses");

				if (resultSet != null) {
					resultSet.last();
					int addressid = resultSet.getInt("addressid");
					pstmt = connection
							.prepareStatement("insert into useraddress (userid,addressid) values(?,?)");
					pstmt.setInt(1, Integer.parseInt(session.getAttribute(
							"userid").toString()));
					pstmt.setInt(2, addressid);
					int rows = pstmt.executeUpdate();
					if (rows == 1) {
						session.setAttribute("addressid", addressid);

					}
				}

			}
			response.sendRedirect("paymentOptions.jsp");
		}
	}

}
