package eCommerce;

import java.sql.*;
public class Login
{
	@SuppressWarnings("finally")
	public static Connection getConnection(String DB)
	{
		Connection con = null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+DB, "root", "root");
			if(con!=null)
			{
				return con;
			}
			
			return null;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("return null as connection");
			return con;
		}
	}
}