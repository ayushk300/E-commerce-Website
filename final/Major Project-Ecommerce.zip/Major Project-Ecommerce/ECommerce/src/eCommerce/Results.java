package eCommerce;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Results {
	
	 public ResultSet getResults(String query) throws SQLException
	 {
		 ResultSet rst=null;
		 ConnectionHandler conHandler=new ConnectionHandler();
	     Connection con=conHandler.getConnection();
	     Statement st=con.createStatement();
	     rst = st.executeQuery(query);
	     return rst;
	 }
}
